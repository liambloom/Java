public class Projects {
  public static void project6 () {
    final String id = Ask.forToken("Please enter your six digit ID");
    if (id.length() != 6) System.out.println("Please input")
    for (int digit = 0; digit <)
  }
}