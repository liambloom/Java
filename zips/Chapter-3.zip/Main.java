class Main {
  public static void main(String[] args) {
    runAllExercises();
  }
  public static void runAllExercises () {
    Exercises.exercise1(7);
    Exercises.exercise2(23);
    Exercises.exercise3(2, 5);
    Exercises.exercise4(3, 7);
    Exercises.exercise5(4, 8);
  }
}