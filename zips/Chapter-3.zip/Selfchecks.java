public class Selfchecks {
    public static String foo () {
        return "FOO".substring(1, 1);
    }
}