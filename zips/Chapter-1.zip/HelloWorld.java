public class HelloWorld { // Class for hello world program
    public static void main () { // Main method
        /*System.out.println("Hello, world!\n");
        System.out.print("This program ");
        System.out.print("doesn't ");
        System.out.println("produce four lines of output\n");
        System.out.println("There is a tab here -->\t<--");
        System.out.println("There's two here -->\t\t<--");
        System.out.println("Here\n are\n some\n newlines");
        System.out.println("The backslash (\\) escapes a character");
        System.out.println("This is useful for things like \\\", which makes a double quote (\")");*/
        
        System.out.println(" 8 + 4 = " + ("8" + "4"));
        System.out.println(" 15 / 5 = " + (15/5));
    }
}